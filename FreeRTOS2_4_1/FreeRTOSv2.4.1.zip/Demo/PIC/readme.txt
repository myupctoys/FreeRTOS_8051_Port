Unfortunately the project files:

RTOSDemo1.mcp
RTOSDemo2.mcp
and RTOSDemo3.mcp

contain absolute paths.  I don't know how to get around this, so if somebody knows, let me know!

Edit the paths in a text editor before use.

See the PIC port section of www.FreeRTOS.org for more information.

