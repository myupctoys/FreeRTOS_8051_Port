/*
	FreeRTOS V2.4.1 - Copyright (C) 2003, 2004 Richard Barry.

	This file is part of the FreeRTOS distribution.

	FreeRTOS is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	FreeRTOS is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS, without being obliged to provide
	the source code for any proprietary components.  See the licensing section 
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************
	See http://www.FreeRTOS.org for documentation, latest information, license 
	and contact details.  Please ensure to read the configuration and relevant 
	port sections of the online documentation.
	***************************************************************************
*/

/*
	Changes from V2.4.0

		+ Made serial ISR handling more complete and robust.
*/

/* BASIC INTERRUPT DRIVEN SERIAL PORT DRIVER FOR UART0. */

/* Standard includes. */
#include <stdlib.h>

/* Scheduler includes. */
#include "projdefs.h"
#include "portable.h"
#include "queue.h"
#include "task.h"

/* Demo application includes. */
#include "serial.h"

/*-----------------------------------------------------------*/

/* Constants to setup and access the UART. */
#define serDLAB							( ( unsigned portCHAR ) 0x80 )
#define serENABLE_INTERRUPTS			( ( unsigned portCHAR ) 0x03 )
#define serNO_PARITY					( ( unsigned portCHAR ) 0x00 )
#define ser1_STOP_BIT					( ( unsigned portCHAR ) 0x00 )
#define ser8_BIT_CHARS					( ( unsigned portCHAR ) 0x03 )
#define serFIFO_ON						( ( unsigned portCHAR ) 0x01 )
#define serCLEAR_FIFO					( ( unsigned portCHAR ) 0x06 )
#define serWANTED_CLOCK_SCALING			( ( unsigned portLONG ) 16 )
#define serINTERRUPT_SOURCE_MASK		( ( unsigned portCHAR ) 0x0f )
#define serSOURCE_THRE					( ( unsigned portCHAR ) 0x02 )
#define serRX_TIMEOUT					( ( unsigned portCHAR ) 0x0c )
#define serSOURCE_ERROR					( ( unsigned portCHAR ) 0x06 )
#define serSOURCE_RX					( ( unsigned portCHAR ) 0x04 )

/* Constants to setup and access the VIC. */
#define serUART0_VIC_CHANNEL			( ( unsigned portLONG ) 0x0006 )
#define serUART0_VIC_CHANNEL_BIT		( ( unsigned portLONG ) 0x0040 )
#define serUART0_VIC_ENABLE				( ( unsigned portLONG ) 0x0020 )
#define serCLEAR_VIC_INTERRUPT			( ( unsigned portLONG ) 0 )

#define serINVALID_QUEUE				( ( xQueueHandle ) 0 )
#define serHANDLE						( ( xComPortHandle ) 1 )
#define serNO_BLOCK						( ( portTickType ) 0 )

/*-----------------------------------------------------------*/

/* Queues used to hold received characters, and characters waiting to be
transmitted. */
static xQueueHandle xRxedChars; 
static xQueueHandle xCharsForTx; 

/*-----------------------------------------------------------*/

/* UART0 interrupt service routine.  This can cause a context switch so MUST
be declared "naked". */
static void vUART_ISR( void ) __attribute__ ((naked));

/* Communication flag between the interrupt service routine and serial API. */
static portLONG lTHREEmpty = pdTRUE;

/*-----------------------------------------------------------*/

xComPortHandle xSerialPortInitMinimal( unsigned portLONG ulWantedBaud, unsigned portCHAR ucQueueLength )
{
unsigned portLONG ulDivisor, ulWantedClock;
xComPortHandle xReturn = serHANDLE;

	/* Create the queues used to hold Rx and Tx characters. */
	xRxedChars = xQueueCreate( ucQueueLength, ( unsigned portCHAR ) sizeof( signed portCHAR ) );
	xCharsForTx = xQueueCreate( ucQueueLength, ( unsigned portCHAR ) sizeof( signed portCHAR ) );

	if( 
		( xRxedChars != serINVALID_QUEUE ) && 
		( xCharsForTx != serINVALID_QUEUE ) && 
		( ulWantedBaud != ( unsigned portLONG ) 0 ) 
	  )
	{
		portENTER_CRITICAL();
		{
			/* Setup the baud rate:  Calculate the divisor value. */
			ulWantedClock = ulWantedBaud * serWANTED_CLOCK_SCALING;
			ulDivisor = portCPU_CLOCK_HZ / ulWantedClock;

			/* Set the DLAB bit so we can access the divisor. */
			UART0_LCR |= serDLAB;

			/* Setup the divisor. */
			UART0_DLL = ( unsigned portCHAR ) ( ulDivisor & ( unsigned portLONG ) 0xff );
			ulDivisor >>= 8;
			UART0_DLM = ( unsigned portCHAR ) ( ulDivisor & ( unsigned portLONG ) 0xff );

			/* Turn on the FIFO's and clear the buffers. */
			UART0_FCR = ( serFIFO_ON | serCLEAR_FIFO );

			/* Setup transmission format. */
			UART0_LCR = serNO_PARITY | ser1_STOP_BIT | ser8_BIT_CHARS;

			/* Setup the VIC for the UART. */
			VICIntSelect &= ~( serUART0_VIC_CHANNEL_BIT );
			VICIntEnable |= serUART0_VIC_CHANNEL_BIT;
			VICVectAddr1 = ( portLONG ) vUART_ISR;
			VICVectCntl1 = serUART0_VIC_CHANNEL | serUART0_VIC_ENABLE;

			/* Enable UART0 interrupts. */
			UART0_IER |= serENABLE_INTERRUPTS;

			/* When we start the THRE must be empty. */
			lTHREEmpty = pdTRUE;
		}
		portEXIT_CRITICAL();
	}
	else
	{
		xReturn = ( xComPortHandle ) 0;
	}

	return xReturn;
}
/*-----------------------------------------------------------*/

signed portCHAR cSerialGetChar( xComPortHandle pxPort, signed portCHAR *pcRxedChar, portTickType xBlockTime )
{
	/* The port handle is not required as this driver only supports UART0. */
	( void ) pxPort;

	/* Get the next character from the buffer.  Return false if no characters
	are available, or arrive before xBlockTime expires. */
	if( cQueueReceive( xRxedChars, pcRxedChar, xBlockTime ) )
	{
		return ( signed portCHAR ) pdTRUE;
	}
	else
	{
		return ( signed portCHAR ) pdFALSE;
	}
}
/*-----------------------------------------------------------*/

void vSerialPutString( xComPortHandle pxPort, const signed portCHAR * const pcString, unsigned portSHORT usStringLength )
{
signed portCHAR *pxNext;

	/* The port handle is not required as this driver only supports UART0. */
	( void ) pxPort;

	/* Send each character in the string, one at a time. */
	pxNext = ( signed portCHAR * ) pcString;
	while( *pxNext )
	{
		cSerialPutChar( pxPort, *pxNext, serNO_BLOCK );
		pxNext++;
	}
}
/*-----------------------------------------------------------*/

signed portCHAR cSerialPutChar( xComPortHandle pxPort, signed portCHAR cOutChar, portTickType xBlockTime )
{
signed portCHAR cReturn;

	portENTER_CRITICAL();
	{
		/* Is there space to write directly to the UART? */
		if( lTHREEmpty )
		{
			/* We wrote the character directly to the UART, so was 
			successful. */
			lTHREEmpty = pdFALSE;
			UART0_THR = cOutChar;
			cReturn = ( signed portCHAR ) pdPASS;
		}
		else 
		{
			/* We cannot write directly to the UART, so queue the character.
			Block for a maximum of xBlockTime if there is no space in the
			queue. */
			cReturn = cQueueSend( xCharsForTx, &cOutChar, xBlockTime );
		}
	}
	portEXIT_CRITICAL();

	return cReturn;
}
/*-----------------------------------------------------------*/

void vSerialClose( xComPortHandle xPort )
{
	/* Not supported as not required by the demo application. */
}
/*-----------------------------------------------------------*/

static void vUART_ISR( void )
{
	/* This ISR can cause a context switch, so the first statement must be a
	call to the portENTER_SWITCHING_ISR() macro.  This must be BEFORE any
	variable declarations. */
	portENTER_SWITCHING_ISR();

	/* Now we can declare the local variables. */
	signed portCHAR cChar, cTaskWokenByTx = ( signed portCHAR ) pdFALSE;
	portLONG lTaskWokenByRx = ( portLONG ) pdFALSE, lDidSomething = ( portLONG ) pdTRUE;

	while( lDidSomething )
	{
		/* What caused the interrupt? */
		switch( UART0_IIR & serINTERRUPT_SOURCE_MASK )
		{
			case serSOURCE_ERROR :	/* Not handling this, but clear the interrupt. */
									cChar = UART0_LSR;
									break;

			case serSOURCE_THRE	:	/* The THRE is empty.  If there is another
									character in the Tx queue, send it now. */
									if( cQueueReceiveFromISR( xCharsForTx, &cChar, &cTaskWokenByTx ) == ( signed portCHAR ) pdTRUE )
									{
										UART0_THR = cChar;
									}
									else
									{
										/* There are no further characters 
										queued to send so we can indicate 
										that the THRE is available. */
										lTHREEmpty = pdTRUE;
									}
									break;

			case serRX_TIMEOUT	:
			case serSOURCE_RX	:	/* A character was received.  Place it in 
									the queue of received characters. */
									cChar = UART0_RBR;
									if( cQueueSendFromISR( xRxedChars, &cChar, pdFALSE ) )
									{
										lTaskWokenByRx = ( portLONG ) pdTRUE;
									}
									break;

			default				:	/* There is nothing to do, leave the ISR. */
									lDidSomething = pdFALSE;
									break;
		}
	}

	/* Clear the ISR in the VIC. */
	VICVectAddr = serCLEAR_VIC_INTERRUPT;

	/* Exit the ISR.  If a task was woken by either a character being received
	or transmitted then a context switch will occur. */
	portEXIT_SWITCHING_ISR( ( cTaskWokenByTx || lTaskWokenByRx ) );
}
/*-----------------------------------------------------------*/





	
