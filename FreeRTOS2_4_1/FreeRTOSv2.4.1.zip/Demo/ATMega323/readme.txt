This directory holds both the WinAVR makefile and the IAR Embedded Workbench workspace.

See http://www.FreeRTOS.org for build instructions and updates.


1) WINAVR
---------

Please read the AVR pages on the WEB site for important information.

Use the makefile and batch files in this directory if using the September 2003 WinAVR build.

Replace the makefile and buildcoff.bat files with those found in the OldWinAVR directory if using a WinAVR version prior to the September 2003 release.

2) IAR
------

Open rtosdemo.eww from within Embedded Workbench.
